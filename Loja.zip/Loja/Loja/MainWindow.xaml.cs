﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace Loja
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            
            InitializeComponent();
        }

        private void BtProdutos_Click(object sender, RoutedEventArgs e)
        {
            Produtos prod = new Produtos();
            prod.Show();
            this.Close();
            
        }


        private void BtnSair_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void BtnVenda_Click(object sender, RoutedEventArgs e)
        {
            CadastrarVenda venda = new CadastrarVenda();
            venda.Show();
            this.Close();
        }

        private void BtnCadastrarProduto_Click(object sender, RoutedEventArgs e)
        {
            CadastrarProduto cadp = new CadastrarProduto();
            cadp.Show();
            this.Close();

        }

        private void BtnCadastrarUsu_Click(object sender, RoutedEventArgs e)
        {
            CadastrarUsuario usu = new CadastrarUsuario();
            usu.Show();
            this.Close();
        }

        private void BtnCadCliente_Click(object sender, RoutedEventArgs e)
        {
            CadastrarCliente usu = new CadastrarCliente();
            usu.Show();
            this.Close();
        }

        private void BntCadTipo_Click(object sender, RoutedEventArgs e)
        {
            CadastrarTipo usu = new CadastrarTipo();
            usu.Show();
            this.Close();

        }
    }
}
