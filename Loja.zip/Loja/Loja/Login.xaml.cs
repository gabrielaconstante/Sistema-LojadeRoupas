﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace Loja
{
    /// <summary>
    /// Lógica interna para Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }
        string usuario;
        string senha;
        MySqlConnection conexao;
        

        public void Logar()
        {
            conexao = new MySqlConnection("Server=127.0.0.1;Database=loja;Uid=root;");
            string selectlogin = "SELECT NOMEUSUARIO, SENHA FROM USUARIO WHERE NOMEUSUARIO='" + NmUsuario.Text + "' AND SENHA='" + SenUsuario.Text + "'";
            MySqlCommand comando = new MySqlCommand(selectlogin, conexao);
            comando.CommandType = System.Data.CommandType.Text;
            MySqlDataReader dr;
            try
            {
                
                conexao.Open();
                dr = comando.ExecuteReader();
                if (dr.Read()) 
                {
                    usuario = dr[0].ToString();
                    senha = dr[1].ToString();
                    conexao.Close();
                    if(usuario==NmUsuario.Text && senha==SenUsuario.Text)
                    {
                      
                        MainWindow princ = new MainWindow();
                        princ.Show();
                        this.Close();
                    }
                   
                }
                else
                {
                    MessageBox.Show("Usuário ou Senha inválidos! Tente outra vez.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }


        }

        private void BtnEntrar_Click(object sender, RoutedEventArgs e)
        {
            

        }

        private void BtnEntrar_Click_1(object sender, RoutedEventArgs e)
        {
            /*MainWindow princ = new MainWindow();
            princ.Show();
            this.Close();*/
            Logar();
        }
    }
}
