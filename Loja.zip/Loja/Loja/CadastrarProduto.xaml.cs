﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace Loja
{
    /// <summary>
    /// Lógica interna para CadastrarProduto.xaml
    /// </summary>
    public partial class CadastrarProduto : Window
    {
        public CadastrarProduto()
        {
            InitializeComponent();
        }


        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void VoltarCadProd_Click(object sender, RoutedEventArgs e)
        {
            MainWindow princ = new MainWindow();
            princ.Show();
            this.Close();
        }

        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string srtSQL;

        private void BtnCadProd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                conexao = new MySqlConnection("Server=127.0.0.1;Database=loja;Uid=root;");

                srtSQL = "INSERT INTO ROUPA( NOME, CODTIPO ,TAMANHO,COR) VALUES (@NOME, @CODTIPO,@TAMANHO,@COR)";

                comando =new MySqlCommand(srtSQL, conexao);
                
                comando.Parameters.AddWithValue("@NOME", TxtBNomeR.Text);
                comando.Parameters.AddWithValue("@TAMANHO", TxtBTamRoupa.Text);
                comando.Parameters.AddWithValue("@COR", TxtBCorRoupa.Text);
                comando.Parameters.AddWithValue("@CODTIPO", Convert.ToInt16(TxtBCodTipoRoupa.Text));

                conexao.Open();    
                comando.ExecuteNonQuery();

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }
            

    }
        

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                conexao = new MySqlConnection("Server=127.0.0.1;Database=loja;Uid=root;");

                
                srtSQL = "UPDATE ROUPA SET NOME=@NOME , CODTIPO=@CODTIPO ,TAMANHO=@TAMANHO, COR=@COR WHERE CODROUPA=@CODROUPA";

                comando = new MySqlCommand(srtSQL, conexao);
                comando.Parameters.AddWithValue("@CODROUPA", Convert.ToInt16(TxtBCodRoupa.Text));
                comando.Parameters.AddWithValue("@NOME", TxtBNomeR.Text);
                comando.Parameters.AddWithValue("@TAMANHO", TxtBTamRoupa.Text);
                comando.Parameters.AddWithValue("@COR", TxtBCorRoupa.Text);
                comando.Parameters.AddWithValue("@CODTIPO", Convert.ToInt16(TxtBCodTipoRoupa.Text));

                conexao.Open();
                comando.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }

        }

        private void BtnExcluProd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                conexao = new MySqlConnection("Server=127.0.0.1;Database=loja;Uid=root;");

                srtSQL = "DELETE FROM ROUPA WHERE CODROUPA=@CODROUPA";

                comando = new MySqlCommand(srtSQL, conexao);

                comando.Parameters.AddWithValue("@CODROUPA", Convert.ToInt16(TxtBCodRoupa.Text));

                conexao.Open();
                comando.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }

        }

        private void DtGridRoupa_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
                       
        }

        private void BtnExibirProd_Click(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
