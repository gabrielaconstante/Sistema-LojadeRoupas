﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace Loja
{
    /// <summary>
    /// Lógica interna para CadastrarCliente.xaml
    /// </summary>
    public partial class CadastrarCliente : Window
    {
        public CadastrarCliente()
        {
            InitializeComponent();
        }

        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string srtSQL;

        private void BtnCatCliente_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                conexao = new MySqlConnection("Server=127.0.0.1;Database=loja;Uid=root;");

                srtSQL = "INSERT INTO CLIENTE( NOMECLIENTE, TELEFONE ,DATACRIACAO) VALUES (@NOMECLIENTE, @TELEFONE ,@DATACRIACAO)";

                comando = new MySqlCommand(srtSQL, conexao);

                comando.Parameters.AddWithValue("@NOMECLIENTE", TxtBNomeCliente.Text);
                comando.Parameters.AddWithValue("@TELEFONE", TxtBTelefone.Text);
                comando.Parameters.AddWithValue("@DATACRIACAO", Convert.ToDateTime(TxtBDataCriacao.Text));
                

                conexao.Open();
                comando.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }
        }

        private void BtnRecarregarBanco_Click(object sender, RoutedEventArgs e)
        {
            CarregarDados();
        }

        public void CarregarDados()
        {
            try
            {
                conexao = new MySqlConnection("Server=127.0.0.1;Database=loja;Uid=root;convert zero datetime=True");

                srtSQL = "SELECT * FROM CLIENTE";

                comando = new MySqlCommand(srtSQL, conexao);

                da = new MySqlDataAdapter(comando);
                DataTable dt = new DataTable();
                da.Fill(dt);

                DtgClientes.ItemsSource = dt.DefaultView;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
        }

        private void BtnVoltarCadCliente_Click(object sender, RoutedEventArgs e)
        {
            MainWindow usu = new MainWindow();
            usu.Show();
            this.Close();
        }

        private void Win_Loaded(object sender, RoutedEventArgs e)
        {
            CarregarDados();
        }
    }
}
