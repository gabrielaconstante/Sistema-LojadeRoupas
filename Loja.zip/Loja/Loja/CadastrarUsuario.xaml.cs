﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace Loja
{
    /// <summary>
    /// Lógica interna para CadastrarUsuario.xaml
    /// </summary>
    public partial class CadastrarUsuario : Window
    {

        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string srtSQL;

        public CadastrarUsuario()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void CadUsuario_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                conexao = new MySqlConnection("Server=127.0.0.1;Database=loja;Uid=root;");

                srtSQL = "INSERT INTO USUARIO( NOMEUSUARIO, CPF ,SENHA ,DATACRIACAO) VALUES (@NOMEUSUARIO, @CPF,@SENHA,@DATACRIACAO)";

                comando = new MySqlCommand(srtSQL, conexao);

                comando.Parameters.AddWithValue("@NOMEUSUARIO", TxtBnomeUsuario.Text);
                comando.Parameters.AddWithValue("@CPF", TxtCPF.Text);
                comando.Parameters.AddWithValue("@SENHA", TxtSenha.Text);
                comando.Parameters.AddWithValue("@DATACRIACAO", Convert.ToDateTime(TxtdataCriacao.Text));

                conexao.Open();
                comando.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }
        }

        private void ExcluirUsu_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                conexao = new MySqlConnection("Server=127.0.0.1;Database=loja;Uid=root;");

                srtSQL = "DELETE FROM USUARIO WHERE NOMEUSUARIO=@NOMEUSUARIO";

                comando = new MySqlCommand(srtSQL, conexao);

                comando.Parameters.AddWithValue("@NOMEUSUARIO", TxtBnomeUsuario.Text);

                conexao.Open();
                comando.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }
        }

   
        private void ExibirUsu_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                conexao = new MySqlConnection("Server=127.0.0.1;Database=loja;Uid=root;");

                srtSQL = "SELECT * FROM USUARIO";

                comando = new MySqlCommand(srtSQL, conexao);

                da = new MySqlDataAdapter(comando);
                DataTable dt = new DataTable();
                da.Fill(dt);

                DtGrUsuario.ItemsSource = dt.DefaultView;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }
        }

        private void BtnVoltar_Click(object sender, RoutedEventArgs e)
        {
            MainWindow usu = new MainWindow();
            usu.Show();
            this.Close();
        }
    }
}
