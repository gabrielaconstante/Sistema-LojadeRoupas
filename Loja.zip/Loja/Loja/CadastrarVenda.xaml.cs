﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;


namespace Loja
{
    /// <summary>
    /// Lógica interna para CadastrarVenda.xaml
    /// </summary>
    public partial class CadastrarVenda : Window
    {
        public CadastrarVenda()
        {
            InitializeComponent();
        }

        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string srtSQL;

        private void BtnCadCompra_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                conexao = new MySqlConnection("Server=127.0.0.1;Database=loja;Uid=root;");

                srtSQL = "INSERT INTO VENDA ( NOMECLIENTE , CODCLIENTE ,CODUSUARIO, CODROUPA, VALOR ,DATAVENDA) VALUES (@NOMECLIENTE, @CODCLIENTE, @CODUSUARIO , @CODROUPA, @VALOR ,@DATAVENDA)";

                comando = new MySqlCommand(srtSQL, conexao);

                comando.Parameters.AddWithValue("@NOMECLIENTE", TxtBoxNomeCliente.Text);
                comando.Parameters.AddWithValue("@CODCLIENTE", Convert.ToInt16(TextBoxCodUsuario.Text));
                comando.Parameters.AddWithValue("@CODUSUARIO", Convert.ToInt16(TextBoxCodVendedor.Text));
                comando.Parameters.AddWithValue("@CODROUPA", Convert.ToInt16(TextBoxPecaComprada.Text));
                comando.Parameters.AddWithValue("@VALOR", Convert.ToDecimal(TextBoxValor.Text));
                comando.Parameters.AddWithValue("@DATAVENDA", Convert.ToDateTime(TextBoxDataVenda.Text));

                conexao.Open();
                comando.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }
        }



        private void BtnVoltar_Click(object sender, RoutedEventArgs e)
        {
            MainWindow princ = new MainWindow();
            princ.Show();
            this.Close();
        }
    }
}
