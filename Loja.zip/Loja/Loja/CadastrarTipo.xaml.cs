﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace Loja
{
    /// <summary>
    /// Lógica interna para CadastrarTipo.xaml
    /// </summary>
    public partial class CadastrarTipo : Window
    {
        public CadastrarTipo()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string srtSQL;

        private void BtnCad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                conexao = new MySqlConnection("Server=127.0.0.1;Database=loja;Uid=root;");

                srtSQL = "INSERT INTO TIPO( NOMETIPO, CARACTERISTICAS) VALUES (@NOMETIPO, @CARACTERISTICAS )";

                comando = new MySqlCommand(srtSQL, conexao);

                comando.Parameters.AddWithValue("@NOMETIPO", TxtBNomeT.Text);
                comando.Parameters.AddWithValue("@CARACTERISTICAS", TxtBCarac.Text);


                conexao.Open();
                comando.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }
        }

        private void BtnModificar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                conexao = new MySqlConnection("Server=127.0.0.1;Database=loja;Uid=root;");


                srtSQL = "UPDATE TIPO SET NOMETIPO=@NOMETIPO , CARACTERISTICAS=@CARACTERISTICAS WHERE CODTIPO=@CODTIPO";

                comando = new MySqlCommand(srtSQL, conexao);
                comando.Parameters.AddWithValue("@CODTIPO", Convert.ToInt16(BtnTipo.Text));
                comando.Parameters.AddWithValue("@NOMETIPO", TxtBNomeT.Text);
                comando.Parameters.AddWithValue("@CARACTERISTICAS", TxtBCarac.Text);

                conexao.Open();
                comando.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }


        }

        public void CarregarDados()
        {
            try
            {
                conexao = new MySqlConnection("Server=127.0.0.1;Database=loja;Uid=root;convert zero datetime=True");

                srtSQL = "SELECT * FROM TIPO";

                comando = new MySqlCommand(srtSQL, conexao);

                da = new MySqlDataAdapter(comando);
                DataTable dt = new DataTable();
                da.Fill(dt);

                DtgTipo.ItemsSource = dt.DefaultView;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }
        }

        private void BtnReca_Click(object sender, RoutedEventArgs e)
        {
            CarregarDados();
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            CarregarDados();
        }

        private void BtnVoltar_Click(object sender, RoutedEventArgs e)
        {
            MainWindow usu = new MainWindow();
            usu.Show();
            this.Close();
        }
    }
}
